﻿/********************************************
**
**  Solution: 
**  Program Name: PptxToAudio
**  Date Started: 2023-03-16
**  Author: Thaddeus Thomas
**  ----------------------------------------
**  Date Updated: 
**  Edit No: Initial Build
**  Notes: 
**   
**   
**                                          
*********************************************/


using static System.Console;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Presentation;
using Microsoft.Azure.CognitiveServices.Speech;
using A = DocumentFormat.OpenXml.Drawing;


namespace PptxToAudio
{
    class Program
    {
        static void AddAudioToPptx(string pptxFile, string[] audioFiles)
        {
            using var presentationDoc = PresentationDocument.Open(pptxFile, true);
            var presentationPart = presentationDoc.PresentationPart;
            var slideParts = presentationPart.SlideParts;

            for (int i = 0; i < slideParts.Count(); i++)
            {
                var slidePart = slideParts.ElementAt(i);
                var notesSlidePart = slidePart.NotesSlidePart;

                if (notesSlidePart == null) continue;

                var slideId = presentationPart.GetIdOfPart(slidePart);
                var notesSlideId = presentationPart.GetIdOfPart(notesSlidePart);

                var slide = slidePart.Slide;
                var slideShapeTree = slide.Descendants<A.ShapeTree>().FirstOrDefault();
                var slideShapes = slideShapeTree.Descendants<A.Shape>().ToList();

                foreach (var audioFile in audioFiles)
                {
                    int audioIndex = int.Parse(Path.GetFileNameWithoutExtension(audioFile).Split("_")[1]) - 1;

                    var audioShape = slideShapes.FirstOrDefault(s => s.NonVisualShapeProperties.NonVisualDrawingProperties.Name.Value == $"Audio {audioIndex + 1}");
                    if (audioShape == null) continue;

                    var audioPart = slidePart.AddNewPart<MediaDataPart>("audio/mp3", $"../media/{audioFile}");
                    using var fileStream = new FileStream(audioFile, FileMode.Open, FileAccess.Read);
                    audioPart.FeedData(fileStream);

                    var audioReference = new A.Audio(
                        new A.AudioProperties(new A.NoAudio()),
                        new A.NonVisualAudioProperties(
                            new A.NonVisualDrawingProperties { Name = $"Audio {audioIndex + 1}" },
                            new A.NonVisualAudioPropertiesExtensionList(
                                new A.NonVisualAudioPropertiesExtension { Uri = "{D42A27DB-F61F-4B5F-9225-5DA5B5B5AABE}" })))
                    {
                        Id = presentationPart.GetIdOfPart(audioPart)
                    };

                    var existingAudioReference = audioShape.Descendants<A.Audio>().FirstOrDefault();
                    if (existingAudioReference == null)
                    {
                        audioShape.AppendChild(new A.ShapeProperties(new A.NoFill(), new A.NoLine(), new A.NoFill(), new A.NoFill(), new A.NoFill(), new A.EffectList(), new A.EffectDag(), new A.Scene3D(), new A.Shape3D(), new A.ShapePropertiesExtensionList(), new A.Transform2D(), new A.CustomGeometry()));
                        audioShape.AppendChild(new A.ShapeStyle());
                        audioShape.AppendChild(new A.AudioFile(new A.AudioFileSourceLink { Id = audioReference.Id }));
                    }
                    else
                    {
                        existingAudioReference.AudioFile.SourceLinkedElement.Id = audioReference.Id;
                    }

                    var commonSlideData = slide.Descendants<A.CommonSlideData>().FirstOrDefault();
                    var timeNode = commonSlideData.Descendants<A.TimeNode>().FirstOrDefault(t => t.NodeType == A.TimeNodeType.TnSequence);
                    if (timeNode == null) continue;

                    var previousAnimation = timeNode.Descendants<A.ParallelTime>().LastOrDefault();

                    var animationId = "animation" + audioIndex;
                    var animationTarget = $"#{audioShape.ShapeId}";

                    var mediaNode = new A.MediaNode(
                        new A.TimeAnimateValueList(
                            new A.TimeAnimateValue
                            {
                                Type = A.TimeAnimateValueType.Shape,
                                Value = animationTarget,
                                TimeNode = new A.TimeNode { NodeType = A.TimeNodeType.TnAnimate }
                            }),
                        new A.TimeAnimationElement(
                            new A.TimeNode { NodeType = A.TimeNodeType.TnAnimate },
                            new A.TimeTargetElement(
                                new A.ShapeTarget { ElementRef = animationTarget },
                                new A.SubShapeElement { Type = A.SubShapeType.Audio })),
                        new A.TimeAnimationDelay { Duration = "0s" },
                        new A.TimeAnimationDuration { Duration = "indefinite" },
                        new A.TimeAnimationRepeatCount { NumberOfRepeats = 1 },
                        new A.TimeAnimationFill { FillType = A.TimeAnimationFillType.Freeze },
                        new A.TimeAnimationRestart { RestartMode = A.TimeAnimationRestartMode.Never },
                        new A.TimeAnimationBegins { BeginsMode = A.TimeAnimationBeginsMode.AutoReverse },
                        new A.TimeAnimationEnds { EndsMode = A.TimeAnimationEndsMode.AutoReverse })
                    {
                        Id = animationId
                    };

                    if (previousAnimation == null)
                    {
                        timeNode.AppendChild(mediaNode);
                    }
                    else
                    {
                        timeNode.InsertAfter(mediaNode, previousAnimation);
                    }
                }
            }

            presentationDoc.Save();
        }

        static string[] ExtractNotes(string pptxFile)
        {
            using var presentationDoc = PresentationDocument.Open(pptxFile, false);
            var presentationPart = presentationDoc.PresentationPart;
            var slideParts = presentationPart.SlideParts;

            return slideParts.Select(slidePart =>
            {
                var notesSlidePart = slidePart.NotesSlidePart;
                if (notesSlidePart == null) return "";

                var notesText = notesSlidePart.NotesSlide.Descendants<A.Paragraph>().Select(p => p.InnerText);
                return string.Join("\n", notesText);
            }).ToArray();
        }

        static async Task<string[]> GenerateAudioFilesAsync(string[] notes)
        {
            // You need to replace the API key and region with your own
            string apiKey = "your-api-key";
            string region = "your-region";

            var config = SpeechConfig.FromSubscription(apiKey, region);
            config.SpeechSynthesisLanguage = "en-US";

            using var synthesizer = new SpeechSynthesizer(config);

            return await Task.WhenAll(notes.Select(async (text, index) =>
            {
                if (string.IsNullOrWhiteSpace(text)) return "";

                string outputFile = $"audio_{index + 1}.mp3";
                using var result = await synthesizer.SpeakTextAsync(text);

                if (result.Reason == ResultReason.Synthesizing
                && result.AudioData != null)
                {
                    using var fileStream = new FileStream(outputFile, FileMode.Create, FileAccess.Write);
                    await result.AudioData.CopyToAsync(fileStream);
                }

                return outputFile;
            })).ConfigureAwait(false);
        }

        static async Task Main(string[] args)
        {
            if (args.Length != 1)
            {
                WriteLine("Usage: PptxToAudio <input_pptx_file>");
                return;
            }

            string inputPptxFile = args[0];
            string outputCsvFile = Path.ChangeExtension(inputPptxFile, ".csv");

            // Extract notes and save as CSV
            var notes = ExtractNotes(inputPptxFile);
            SaveNotesAsCsv(notes, outputCsvFile);

            // Use spellchecker or grammar checker API here to correct the text (not included)
            // ...

            // Generate audio files for each note
            var audioFiles = await GenerateAudioFilesAsync(notes);

            // Add audio files to the original PowerPoint file
            AddAudioToPptx(inputPptxFile, audioFiles);
        }
        static void SaveNotesAsCsv(string[] notes, string outputFile)
        {
            using var writer = new StreamWriter(outputFile);
            using var csv = new CsvWriter(writer, System.Globalization.CultureInfo.InvariantCulture);
            csv.WriteField("Slide");
            csv.WriteField("Notes");
            csv.NextRecord();

            for (int i = 0; i < notes.Length; i++)
            {
                csv.WriteField(i + 1);
                csv.WriteField(notes[i]);
                csv.NextRecord();
            }
        }
    }
}